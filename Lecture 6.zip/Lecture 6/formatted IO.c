#include<stdio.h>

int main(){
    int p= 10,q= 113;
    printf("1.%10f\n",(float)p);
    printf("2.%05d\n",q);
    printf("3.%10f\n",(float)q);
    printf("4.%.2f\n",(float)q);
    printf("5.%10.2f\n",(float)q);
    return 0;
}
