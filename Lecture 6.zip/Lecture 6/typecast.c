#include<stdio.h>

int main(){
    int p= 10;
    float a= (float)p;
    return 0;
}
