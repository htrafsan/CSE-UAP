#include<stdio.h>

int main(){
    int p= -123423423234;
    printf("%d\n",p);
    return 0;
}
