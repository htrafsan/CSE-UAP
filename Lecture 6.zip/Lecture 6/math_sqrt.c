#include<stdio.h>

int main(){
    float p= 25;
    float sqrt_p= sqrt(30);
    int int_conv= sqrt_p;
    printf("%f\n",sqrt_p);
    printf("%d\n",int_conv);
    return 0;
}
