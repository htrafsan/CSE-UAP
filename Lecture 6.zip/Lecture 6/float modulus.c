#include<stdio.h>

int main(){
    float p= 10;
    int q= p/(float)(3.0);
    printf("%d\n",q);
    return 0;
}
