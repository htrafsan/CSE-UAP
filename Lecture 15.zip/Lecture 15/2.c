#include<stdio.h>

int main() {
    char s[15],t;
    scanf("%c",&s[0]);
    scanf("%c",&t);
    scanf("%c",&s[1]);
    scanf("%c",&t);
    scanf("%c",&s[2]);
    printf("s[0]= '%c'\n",s[0]);
    printf("s[1]= '%c'\n",s[1]);
    printf("s[2]= '%c'\n",s[2]);
    return 0;
}
