#include<stdio.h>

const int a=2,b=10;

void sum() {
//    a= 7,b=20;
}

void main() {
//    a= 6,b= 19;
    sum();
    printf("%d %d\n",a,b);
    return 0;
}





