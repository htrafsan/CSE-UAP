#include<stdio.h>

int main() {
    int a[5];
    a[0]= 5;
    scanf("%d",&a[1]);
    printf("%d %d %d\n",a[0],a[1],a[2]);
    return 0;
}
