#include<stdio.h>

int main() {
    int i,n;
    int a[]= {1,3,2,8};

    for (i=0;i<4;i+=1) {
        printf("%d ",a[i]);
    }
    return 0;
}
