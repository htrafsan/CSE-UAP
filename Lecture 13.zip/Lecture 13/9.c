#include<stdio.h>

int main() {
    int i,j,n;
    scanf("%d",&n);
    int a[n],b[n];
    for (i=0;i<n;i+=1) {
        scanf("%d",&a[i]);
    }
    /// store the numbers in another array in reverse order
    /// input array: 1 3 2 9 7
    /// second array: 7 9 2 3 1
    return 0;
}
