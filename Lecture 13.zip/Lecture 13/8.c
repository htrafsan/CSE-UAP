#include<stdio.h>

int main() {
    int i,j,n;
    scanf("%d",&n);
    int a[n];
    for (i=0;i<n;i+=1) {
        scanf("%d",&a[i]);
    }
    /// print the numbers in reverse order
    return 0;
}
