#include<stdio.h>

int main() {
    int n= 0x10;
    //scanf("%x",&n);
    printf("Octal: %o\n",n);
    printf("Decimal: %d\n",n);
    printf("Hexa (small letter):%x\n",n);
    printf("Hexa (Cap letter):%X\n",n);
    return 0;
}
