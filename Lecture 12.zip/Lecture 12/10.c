#include<stdio.h>
#include<math.h>

int main() {
    float ans= log10(64);
    printf("%f\n",ans);
    return 0;
}
