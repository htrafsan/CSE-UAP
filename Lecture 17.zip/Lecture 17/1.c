#include<stdio.h>

int main() {
    int a[3][5];
    a[0][1]= 1;
    printf("%d\n",a[0][1]);
    return 0;
}
