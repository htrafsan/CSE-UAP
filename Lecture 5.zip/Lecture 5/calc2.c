#include <stdio.h>

int main() {
    float a,b;
    a= 5.23;
    printf("%f",a);
    scanf("%f",&b);
    printf("%f",b);

    return 0;
}
