#include<stdio.h>

int main() {
    int p;
    scanf("%d",&p);

    if (p>=0)
        printf("Non-negative\n");
    else
        printf("Negative\n");



    return 0;
}
