#include<iostream>
#include<cstdio>
using namespace std;

int n;

//write your recursive function



int main()
{

    cout<<"enter n:";
    cin>>n;

    //write your code

    return 0;
}
